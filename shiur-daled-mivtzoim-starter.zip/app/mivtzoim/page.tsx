export default function MivtzoimPage() {
  return <div className="p-6 md:p-8"><h1 className="text-2xl font-semibold">My Mivtzoim</h1><p className="mt-2 text-neutral-500">Record and manage your Mivtzoim activity here.</p></div>;
}
