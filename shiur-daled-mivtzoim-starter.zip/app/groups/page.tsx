export default function GroupsPage() {
  return <div className="p-6 md:p-8"><h1 className="text-2xl font-semibold">My Groups</h1><p className="mt-2 text-neutral-500">Your chavrusa and Mivtzoim groups will appear here.</p></div>;
}
