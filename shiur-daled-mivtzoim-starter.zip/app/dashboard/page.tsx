import { Candle, MapPinned, Plus, Users, Watch } from "lucide-react";
import { StatCard } from "@/components/dashboard/stat-card";

const stats = [
  { label: "Tefillin", value: 127, icon: Watch },
  { label: "Shabbos Candles", value: 63, icon: Candle },
  { label: "Mezuzah", value: 24, icon: MapPinned },
];

export default function DashboardPage() {
  return (
    <div className="mx-auto max-w-7xl p-5 md:p-8">
      <header className="mb-8 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-sm font-medium text-neutral-500">Shiur Daled Mivtzoim</p>
          <h1 className="mt-1 text-3xl font-semibold tracking-tight">My Mivtzoim</h1>
          <p className="mt-2 text-neutral-500">Go out. Do Mitzvos. Make an impact.</p>
        </div>
        <button className="inline-flex items-center justify-center gap-2 rounded-xl bg-neutral-900 px-5 py-3 text-sm font-semibold text-white shadow-sm">
          <Plus size={18} /> Add Mivtzoim
        </button>
      </header>

      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {stats.map((stat) => <StatCard key={stat.label} {...stat} />)}
      </section>

      <section className="mt-8 grid gap-6 lg:grid-cols-2">
        <div className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">This Week</h2>
            <span className="text-sm text-neutral-500">Sep 21–27</span>
          </div>
          <div className="mt-5 space-y-4">
            <Row label="Tefillin" value="8" />
            <Row label="Shabbos Candles" value="12" />
            <Row label="Mezuzah" value="3" />
          </div>
        </div>

        <div className="rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-neutral-100 p-3"><Users size={20} /></div>
            <div>
              <h2 className="font-semibold">My Group</h2>
              <p className="text-sm text-neutral-500">Tzvi & Moshe</p>
            </div>
          </div>
          <div className="mt-6">
            <div className="mb-2 flex justify-between text-sm">
              <span className="font-medium">Weekly Route</span>
              <span className="text-neutral-500">4 / 7 completed</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-neutral-100">
              <div className="h-full w-[57%] rounded-full bg-neutral-900" />
            </div>
          </div>
        </div>
      </section>

      <section className="mt-6 rounded-2xl border border-neutral-200 bg-white p-6 shadow-sm">
        <h2 className="text-lg font-semibold">Recent Activity</h2>
        <div className="mt-4 divide-y divide-neutral-100">
          <Row label="Main Street Store — Tefillin" value="+4" />
          <Row label="Office Building — Shabbos Candles" value="+6" />
        </div>
      </section>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between py-3">
      <span className="text-sm text-neutral-600">{label}</span>
      <span className="font-semibold">{value}</span>
    </div>
  );
}
