export default function HistoryPage() {
  return <div className="p-6 md:p-8"><h1 className="text-2xl font-semibold">History</h1><p className="mt-2 text-neutral-500">Your historical Mivtzoim activity will appear here.</p></div>;
}
