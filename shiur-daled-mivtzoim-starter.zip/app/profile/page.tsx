export default function ProfilePage() {
  return <div className="p-6 md:p-8"><h1 className="text-2xl font-semibold">Profile</h1><p className="mt-2 text-neutral-500">Manage your profile and personal categories here.</p></div>;
}
